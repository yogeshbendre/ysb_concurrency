var testdata = {
    "nic": {
        "w1-hs4-n2211.eng.vmware.com": [
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778020000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778031000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 14, 
                "Time": 1566778042000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 14, 
                "Time": 1566778053000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778064000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778075000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 15, 
                "Time": 1566778086000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 15, 
                "Time": 1566778097000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778107000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778118000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 16, 
                "Time": 1566778129000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 12, 
                "Time": 1566778140000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 12, 
                "Time": 1566778151000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 16, 
                "Time": 1566778161000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 16, 
                "Time": 1566778172000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 12, 
                "Time": 1566778183000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 12, 
                "Time": 1566778194000
            }
        ], 
        "w1-hs4-n2201.eng.vmware.com": [
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778019000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778030000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 14, 
                "Time": 1566778041000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 14, 
                "Time": 1566778052000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778063000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778074000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 15, 
                "Time": 1566778085000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 15, 
                "Time": 1566778096000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778106000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778117000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 16, 
                "Time": 1566778128000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 16, 
                "Time": 1566778139000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 12, 
                "Time": 1566778150000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 16, 
                "Time": 1566778160000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 16, 
                "Time": 1566778171000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 12, 
                "Time": 1566778182000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 12, 
                "Time": 1566778193000
            }
        ], 
        "w1-hs4-n2206.eng.vmware.com": [
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778020000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778030000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 14, 
                "Time": 1566778041000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 14, 
                "Time": 1566778052000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778063000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778074000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 15, 
                "Time": 1566778085000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 15, 
                "Time": 1566778096000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778106000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778117000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 16, 
                "Time": 1566778128000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 16, 
                "Time": 1566778139000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 12, 
                "Time": 1566778150000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 16, 
                "Time": 1566778160000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 16, 
                "Time": 1566778171000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 12, 
                "Time": 1566778182000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 12, 
                "Time": 1566778193000
            }
        ], 
        "w1-hs4-n2214.eng.vmware.com": [
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778021000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778032000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 14, 
                "Time": 1566778043000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 14, 
                "Time": 1566778054000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778065000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778076000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 15, 
                "Time": 1566778086000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 15, 
                "Time": 1566778097000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778108000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 13, 
                "Time": 1566778119000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 16, 
                "Time": 1566778129000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 12, 
                "Time": 1566778140000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 12, 
                "Time": 1566778151000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 16, 
                "Time": 1566778162000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 16, 
                "Time": 1566778172000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 12, 
                "Time": 1566778183000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 12, 
                "Time": 1566778194000
            }
        ]
    }, 
    "datastore": {
        "Local-2201-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778019000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778030000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778041000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778052000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778063000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778074000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778085000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778096000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778106000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778117000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778128000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778139000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778150000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778160000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778171000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778182000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778193000
            }
        ], 
        "Local-2211-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778020000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778031000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778042000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778053000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778064000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778075000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778086000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778097000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778107000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778118000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778129000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778140000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778151000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778161000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778172000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778183000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778194000
            }
        ], 
        "Local-2206-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778020000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778030000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778041000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778052000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778063000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778074000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778085000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778096000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778106000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778117000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778128000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778139000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778150000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778160000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778171000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778182000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778193000
            }
        ], 
        "Local-2214-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778021000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778032000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778043000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778054000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778065000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778076000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778086000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778097000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778108000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778119000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778129000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778140000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778151000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778162000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778172000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778183000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778194000
            }
        ]
    }, 
    "vm": {
        "Test-VM-01": [
            {
                "Progress": 0, 
                "Time": 1566778010000
            }, 
            {
                "Progress": 29, 
                "Time": 1566778010000
            }, 
            {
                "Progress": 29, 
                "Time": 1566778013000
            }, 
            {
                "Progress": 30, 
                "Time": 1566778020000
            }, 
            {
                "Progress": 32, 
                "Time": 1566778026000
            }, 
            {
                "Progress": 35, 
                "Time": 1566778034000
            }, 
            {
                "Progress": 37, 
                "Time": 1566778041000
            }, 
            {
                "Progress": 40, 
                "Time": 1566778047000
            }, 
            {
                "Progress": 42, 
                "Time": 1566778054000
            }, 
            {
                "Progress": 43, 
                "Time": 1566778061000
            }, 
            {
                "Progress": 46, 
                "Time": 1566778067000
            }, 
            {
                "Progress": 49, 
                "Time": 1566778074000
            }, 
            {
                "Progress": 51, 
                "Time": 1566778081000
            }, 
            {
                "Progress": 54, 
                "Time": 1566778087000
            }, 
            {
                "Progress": 57, 
                "Time": 1566778093000
            }, 
            {
                "Progress": 59, 
                "Time": 1566778100000
            }, 
            {
                "Progress": 61, 
                "Time": 1566778106000
            }, 
            {
                "Progress": 63, 
                "Time": 1566778112000
            }, 
            {
                "Progress": 66, 
                "Time": 1566778119000
            }, 
            {
                "Progress": 68, 
                "Time": 1566778125000
            }, 
            {
                "Progress": 71, 
                "Time": 1566778132000
            }, 
            {
                "Progress": 73, 
                "Time": 1566778138000
            }, 
            {
                "Progress": 76, 
                "Time": 1566778144000
            }, 
            {
                "Progress": 78, 
                "Time": 1566778151000
            }, 
            {
                "Progress": 81, 
                "Time": 1566778157000
            }, 
            {
                "Progress": 84, 
                "Time": 1566778164000
            }, 
            {
                "Progress": 86, 
                "Time": 1566778171000
            }, 
            {
                "Progress": 88, 
                "Time": 1566778177000
            }, 
            {
                "Progress": 91, 
                "Time": 1566778184000
            }, 
            {
                "Progress": 100, 
                "Time": 1566778190000
            }
        ], 
        "Test-VM-03": [
            {
                "Progress": 0, 
                "Time": 1566778010000
            }, 
            {
                "Progress": 29, 
                "Time": 1566778010000
            }, 
            {
                "Progress": 29, 
                "Time": 1566778013000
            }, 
            {
                "Progress": 30, 
                "Time": 1566778020000
            }, 
            {
                "Progress": 35, 
                "Time": 1566778026000
            }, 
            {
                "Progress": 38, 
                "Time": 1566778034000
            }, 
            {
                "Progress": 42, 
                "Time": 1566778040000
            }, 
            {
                "Progress": 45, 
                "Time": 1566778047000
            }, 
            {
                "Progress": 49, 
                "Time": 1566778054000
            }, 
            {
                "Progress": 53, 
                "Time": 1566778061000
            }, 
            {
                "Progress": 57, 
                "Time": 1566778067000
            }, 
            {
                "Progress": 61, 
                "Time": 1566778074000
            }, 
            {
                "Progress": 65, 
                "Time": 1566778081000
            }, 
            {
                "Progress": 68, 
                "Time": 1566778087000
            }, 
            {
                "Progress": 72, 
                "Time": 1566778093000
            }, 
            {
                "Progress": 76, 
                "Time": 1566778100000
            }, 
            {
                "Progress": 80, 
                "Time": 1566778106000
            }, 
            {
                "Progress": 83, 
                "Time": 1566778112000
            }, 
            {
                "Progress": 88, 
                "Time": 1566778119000
            }, 
            {
                "Progress": 91, 
                "Time": 1566778125000
            }, 
            {
                "Progress": 100, 
                "Time": 1566778130000
            }
        ], 
        "Test-VM-02": [
            {
                "Progress": 0, 
                "Time": 1566778009000
            }, 
            {
                "Progress": 29, 
                "Time": 1566778009000
            }, 
            {
                "Progress": 29, 
                "Time": 1566778012000
            }, 
            {
                "Progress": 30, 
                "Time": 1566778019000
            }, 
            {
                "Progress": 35, 
                "Time": 1566778026000
            }, 
            {
                "Progress": 38, 
                "Time": 1566778032000
            }, 
            {
                "Progress": 42, 
                "Time": 1566778040000
            }, 
            {
                "Progress": 45, 
                "Time": 1566778047000
            }, 
            {
                "Progress": 49, 
                "Time": 1566778054000
            }, 
            {
                "Progress": 53, 
                "Time": 1566778060000
            }, 
            {
                "Progress": 57, 
                "Time": 1566778067000
            }, 
            {
                "Progress": 61, 
                "Time": 1566778074000
            }, 
            {
                "Progress": 65, 
                "Time": 1566778080000
            }, 
            {
                "Progress": 68, 
                "Time": 1566778087000
            }, 
            {
                "Progress": 72, 
                "Time": 1566778093000
            }, 
            {
                "Progress": 76, 
                "Time": 1566778099000
            }, 
            {
                "Progress": 80, 
                "Time": 1566778106000
            }, 
            {
                "Progress": 84, 
                "Time": 1566778112000
            }, 
            {
                "Progress": 88, 
                "Time": 1566778119000
            }, 
            {
                "Progress": 91, 
                "Time": 1566778125000
            }, 
            {
                "Progress": 100, 
                "Time": 1566778130000
            }
        ], 
        "Test-VM-05": [
            {
                "Progress": 0, 
                "Time": 1566778010000
            }, 
            {
                "Progress": 29, 
                "Time": 1566778010000
            }, 
            {
                "Progress": 29, 
                "Time": 1566778013000
            }, 
            {
                "Progress": 30, 
                "Time": 1566778020000
            }, 
            {
                "Progress": 32, 
                "Time": 1566778026000
            }, 
            {
                "Progress": 35, 
                "Time": 1566778034000
            }, 
            {
                "Progress": 37, 
                "Time": 1566778040000
            }, 
            {
                "Progress": 40, 
                "Time": 1566778047000
            }, 
            {
                "Progress": 42, 
                "Time": 1566778054000
            }, 
            {
                "Progress": 45, 
                "Time": 1566778061000
            }, 
            {
                "Progress": 48, 
                "Time": 1566778067000
            }, 
            {
                "Progress": 49, 
                "Time": 1566778074000
            }, 
            {
                "Progress": 52, 
                "Time": 1566778081000
            }, 
            {
                "Progress": 55, 
                "Time": 1566778087000
            }, 
            {
                "Progress": 57, 
                "Time": 1566778093000
            }, 
            {
                "Progress": 60, 
                "Time": 1566778100000
            }, 
            {
                "Progress": 62, 
                "Time": 1566778106000
            }, 
            {
                "Progress": 65, 
                "Time": 1566778112000
            }, 
            {
                "Progress": 67, 
                "Time": 1566778119000
            }, 
            {
                "Progress": 70, 
                "Time": 1566778125000
            }, 
            {
                "Progress": 72, 
                "Time": 1566778132000
            }, 
            {
                "Progress": 75, 
                "Time": 1566778138000
            }, 
            {
                "Progress": 77, 
                "Time": 1566778144000
            }, 
            {
                "Progress": 79, 
                "Time": 1566778151000
            }, 
            {
                "Progress": 82, 
                "Time": 1566778157000
            }, 
            {
                "Progress": 85, 
                "Time": 1566778164000
            }, 
            {
                "Progress": 88, 
                "Time": 1566778171000
            }, 
            {
                "Progress": 90, 
                "Time": 1566778177000
            }, 
            {
                "Progress": 93, 
                "Time": 1566778184000
            }, 
            {
                "Progress": 100, 
                "Time": 1566778187000
            }
        ]
    }
}