var testdata = {
    "nic": {
        "w1-hs4-n2211.eng.vmware.com": [
            {
                "vnic": "vmnic1", 
                "Bandwidth": 6, 
                "Time": 1566773551000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773561000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773572000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 6, 
                "Time": 1566773583000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 6, 
                "Time": 1566773594000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773604000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773615000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 7, 
                "Time": 1566773626000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 7, 
                "Time": 1566773637000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773648000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773658000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 6, 
                "Time": 1566773669000
            }
        ], 
        "w1-hs4-n2203.eng.vmware.com": [
            {
                "vnic": "vmnic1", 
                "Bandwidth": 6, 
                "Time": 1566773551000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773562000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773572000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 6, 
                "Time": 1566773583000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 6, 
                "Time": 1566773594000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773605000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773616000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 7, 
                "Time": 1566773627000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 7, 
                "Time": 1566773637000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773648000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773659000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 6, 
                "Time": 1566773670000
            }
        ], 
        "w1-hs4-n2208.eng.vmware.com": [
            {
                "vnic": "vmnic1", 
                "Bandwidth": 6, 
                "Time": 1566773551000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773562000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773573000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 6, 
                "Time": 1566773584000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 6, 
                "Time": 1566773595000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773606000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773617000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 7, 
                "Time": 1566773628000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 7, 
                "Time": 1566773638000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773649000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 6, 
                "Time": 1566773660000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 6, 
                "Time": 1566773671000
            }
        ], 
        "w1-hs4-n2213.eng.vmware.com": [
            {
                "vnic": "vmnic1", 
                "Bandwidth": 6, 
                "Time": 1566773550000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773561000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773572000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 6, 
                "Time": 1566773582000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 6, 
                "Time": 1566773593000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773604000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773615000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 7, 
                "Time": 1566773626000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 7, 
                "Time": 1566773636000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773647000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 9, 
                "Time": 1566773658000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 6, 
                "Time": 1566773669000
            }
        ]
    }, 
    "datastore": {
        "Local-2213-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773550000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773561000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773572000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773582000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773593000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773604000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773615000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773626000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773636000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773647000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773658000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773669000
            }
        ], 
        "Local-2208-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773551000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773562000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773573000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773584000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773595000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773606000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773617000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773628000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773638000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773649000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773660000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773671000
            }
        ], 
        "Local-2203-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773551000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773562000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773572000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773583000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773594000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773605000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773616000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773627000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773637000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773648000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773659000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566773670000
            }
        ]
    }, 
    "vm": {
        "Test-VM-03": [
            {
                "Progress": 0, 
                "Time": 1566773542000
            }, 
            {
                "Progress": 29, 
                "Time": 1566773542000
            }, 
            {
                "Progress": 29, 
                "Time": 1566773545000
            }, 
            {
                "Progress": 30, 
                "Time": 1566773551000
            }, 
            {
                "Progress": 34, 
                "Time": 1566773557000
            }, 
            {
                "Progress": 37, 
                "Time": 1566773564000
            }, 
            {
                "Progress": 40, 
                "Time": 1566773570000
            }, 
            {
                "Progress": 43, 
                "Time": 1566773577000
            }, 
            {
                "Progress": 46, 
                "Time": 1566773583000
            }, 
            {
                "Progress": 50, 
                "Time": 1566773590000
            }, 
            {
                "Progress": 54, 
                "Time": 1566773596000
            }, 
            {
                "Progress": 58, 
                "Time": 1566773603000
            }, 
            {
                "Progress": 62, 
                "Time": 1566773609000
            }, 
            {
                "Progress": 65, 
                "Time": 1566773616000
            }, 
            {
                "Progress": 69, 
                "Time": 1566773622000
            }, 
            {
                "Progress": 73, 
                "Time": 1566773629000
            }, 
            {
                "Progress": 76, 
                "Time": 1566773635000
            }, 
            {
                "Progress": 80, 
                "Time": 1566773642000
            }, 
            {
                "Progress": 84, 
                "Time": 1566773648000
            }, 
            {
                "Progress": 88, 
                "Time": 1566773655000
            }, 
            {
                "Progress": 91, 
                "Time": 1566773661000
            }, 
            {
                "Progress": 100, 
                "Time": 1566773666000
            }
        ], 
        "Test-VM-02": [
            {
                "Progress": 0, 
                "Time": 1566773541000
            }, 
            {
                "Progress": 29, 
                "Time": 1566773541000
            }, 
            {
                "Progress": 29, 
                "Time": 1566773544000
            }, 
            {
                "Progress": 30, 
                "Time": 1566773550000
            }, 
            {
                "Progress": 34, 
                "Time": 1566773557000
            }, 
            {
                "Progress": 37, 
                "Time": 1566773563000
            }, 
            {
                "Progress": 40, 
                "Time": 1566773570000
            }, 
            {
                "Progress": 43, 
                "Time": 1566773576000
            }, 
            {
                "Progress": 47, 
                "Time": 1566773583000
            }, 
            {
                "Progress": 51, 
                "Time": 1566773589000
            }, 
            {
                "Progress": 54, 
                "Time": 1566773596000
            }, 
            {
                "Progress": 58, 
                "Time": 1566773602000
            }, 
            {
                "Progress": 62, 
                "Time": 1566773609000
            }, 
            {
                "Progress": 66, 
                "Time": 1566773615000
            }, 
            {
                "Progress": 69, 
                "Time": 1566773622000
            }, 
            {
                "Progress": 73, 
                "Time": 1566773628000
            }, 
            {
                "Progress": 76, 
                "Time": 1566773635000
            }, 
            {
                "Progress": 81, 
                "Time": 1566773641000
            }, 
            {
                "Progress": 84, 
                "Time": 1566773648000
            }, 
            {
                "Progress": 88, 
                "Time": 1566773654000
            }, 
            {
                "Progress": 92, 
                "Time": 1566773660000
            }, 
            {
                "Progress": 100, 
                "Time": 1566773665000
            }
        ], 
        "Test-VM-05": [
            {
                "Progress": 0, 
                "Time": 1566773542000
            }, 
            {
                "Progress": 29, 
                "Time": 1566773542000
            }, 
            {
                "Progress": 29, 
                "Time": 1566773545000
            }, 
            {
                "Progress": 30, 
                "Time": 1566773551000
            }, 
            {
                "Progress": 34, 
                "Time": 1566773557000
            }, 
            {
                "Progress": 37, 
                "Time": 1566773564000
            }, 
            {
                "Progress": 40, 
                "Time": 1566773570000
            }, 
            {
                "Progress": 43, 
                "Time": 1566773577000
            }, 
            {
                "Progress": 47, 
                "Time": 1566773583000
            }, 
            {
                "Progress": 51, 
                "Time": 1566773590000
            }, 
            {
                "Progress": 54, 
                "Time": 1566773596000
            }, 
            {
                "Progress": 58, 
                "Time": 1566773603000
            }, 
            {
                "Progress": 62, 
                "Time": 1566773609000
            }, 
            {
                "Progress": 65, 
                "Time": 1566773616000
            }, 
            {
                "Progress": 68, 
                "Time": 1566773622000
            }, 
            {
                "Progress": 73, 
                "Time": 1566773629000
            }, 
            {
                "Progress": 76, 
                "Time": 1566773635000
            }, 
            {
                "Progress": 80, 
                "Time": 1566773641000
            }, 
            {
                "Progress": 84, 
                "Time": 1566773648000
            }, 
            {
                "Progress": 88, 
                "Time": 1566773654000
            }, 
            {
                "Progress": 91, 
                "Time": 1566773661000
            }, 
            {
                "Progress": 100, 
                "Time": 1566773666000
            }
        ], 
        "Test-VM-07": [
            {
                "Progress": 0, 
                "Time": 1566773541000
            }, 
            {
                "Progress": 0, 
                "Time": 1566773541000
            }
        ]
    }
}