var testdata = {
    "nic": {
        "w1-hs4-n2212.eng.vmware.com": [
            {
                "vnic": "vmnic0", 
                "Bandwidth": 14886, 
                "Time": 1566778764000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 14886, 
                "Time": 1566778774000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 18368, 
                "Time": 1566778785000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 18368, 
                "Time": 1566778796000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 14601, 
                "Time": 1566778807000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 14601, 
                "Time": 1566778818000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4995, 
                "Time": 1566778828000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4995, 
                "Time": 1566778839000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 1596, 
                "Time": 1566778850000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 358, 
                "Time": 1566778861000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 358, 
                "Time": 1566778871000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 281, 
                "Time": 1566778882000
            }
        ], 
        "w1-hs4-n2213.eng.vmware.com": [
            {
                "vnic": "vmnic0", 
                "Bandwidth": 14908, 
                "Time": 1566778763000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 14908, 
                "Time": 1566778774000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 18528, 
                "Time": 1566778785000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 18528, 
                "Time": 1566778796000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 14439, 
                "Time": 1566778807000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 14439, 
                "Time": 1566778817000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 6240, 
                "Time": 1566778828000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 6240, 
                "Time": 1566778839000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 351, 
                "Time": 1566778850000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 358, 
                "Time": 1566778861000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 358, 
                "Time": 1566778871000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 267, 
                "Time": 1566778882000
            }
        ], 
        "w1-hs4-n2201.eng.vmware.com": [
            {
                "vnic": "vmnic0", 
                "Bandwidth": 24667, 
                "Time": 1566778763000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 24667, 
                "Time": 1566778774000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 40356, 
                "Time": 1566778785000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 40356, 
                "Time": 1566778796000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 28565, 
                "Time": 1566778807000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 28565, 
                "Time": 1566778817000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 11435, 
                "Time": 1566778828000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 1450, 
                "Time": 1566778839000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 1450, 
                "Time": 1566778850000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 706, 
                "Time": 1566778861000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 706, 
                "Time": 1566778872000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 451, 
                "Time": 1566778883000
            }
        ], 
        "w1-hs4-n2206.eng.vmware.com": [
            {
                "vnic": "vmnic0", 
                "Bandwidth": 24480, 
                "Time": 1566778764000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 24480, 
                "Time": 1566778774000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 40543, 
                "Time": 1566778785000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 40543, 
                "Time": 1566778796000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 28566, 
                "Time": 1566778807000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 28566, 
                "Time": 1566778818000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 11400, 
                "Time": 1566778828000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 11400, 
                "Time": 1566778839000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 1493, 
                "Time": 1566778850000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 696, 
                "Time": 1566778861000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 696, 
                "Time": 1566778871000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 455, 
                "Time": 1566778882000
            }
        ]
    }, 
    "datastore": {
        "Local-2213-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778763000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778774000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778785000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778796000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778807000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778817000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778828000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778839000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778850000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778861000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778871000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778882000
            }
        ], 
        "Local-2201-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778763000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778774000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778785000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778796000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778807000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778817000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778828000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778839000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778850000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778861000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778872000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778883000
            }
        ], 
        "Local-2212-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778764000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778774000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778785000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778796000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778807000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778818000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778828000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778839000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778850000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778861000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778871000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778882000
            }
        ], 
        "Local-2206-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778764000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778774000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778785000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778796000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778807000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778818000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778828000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778839000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778850000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778861000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778871000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566778882000
            }
        ]
    }, 
    "vm": {
        "Test-VM-08": [
            {
                "Progress": 0, 
                "Time": 1566778754000
            }, 
            {
                "Progress": 34, 
                "Time": 1566778754000
            }, 
            {
                "Progress": 34, 
                "Time": 1566778757000
            }, 
            {
                "Progress": 35, 
                "Time": 1566778763000
            }, 
            {
                "Progress": 39, 
                "Time": 1566778770000
            }, 
            {
                "Progress": 42, 
                "Time": 1566778777000
            }, 
            {
                "Progress": 45, 
                "Time": 1566778783000
            }, 
            {
                "Progress": 48, 
                "Time": 1566778790000
            }, 
            {
                "Progress": 52, 
                "Time": 1566778797000
            }, 
            {
                "Progress": 55, 
                "Time": 1566778803000
            }, 
            {
                "Progress": 58, 
                "Time": 1566778810000
            }, 
            {
                "Progress": 61, 
                "Time": 1566778817000
            }, 
            {
                "Progress": 64, 
                "Time": 1566778823000
            }, 
            {
                "Progress": 68, 
                "Time": 1566778830000
            }, 
            {
                "Progress": 71, 
                "Time": 1566778836000
            }, 
            {
                "Progress": 75, 
                "Time": 1566778843000
            }, 
            {
                "Progress": 78, 
                "Time": 1566778850000
            }, 
            {
                "Progress": 81, 
                "Time": 1566778856000
            }, 
            {
                "Progress": 85, 
                "Time": 1566778863000
            }, 
            {
                "Progress": 88, 
                "Time": 1566778869000
            }, 
            {
                "Progress": 94, 
                "Time": 1566778876000
            }, 
            {
                "Progress": 100, 
                "Time": 1566778877000
            }
        ], 
        "Test-VM-04": [
            {
                "Progress": 0, 
                "Time": 1566778753000
            }, 
            {
                "Progress": 34, 
                "Time": 1566778753000
            }, 
            {
                "Progress": 34, 
                "Time": 1566778756000
            }, 
            {
                "Progress": 35, 
                "Time": 1566778762000
            }, 
            {
                "Progress": 39, 
                "Time": 1566778769000
            }, 
            {
                "Progress": 42, 
                "Time": 1566778776000
            }, 
            {
                "Progress": 45, 
                "Time": 1566778783000
            }, 
            {
                "Progress": 48, 
                "Time": 1566778789000
            }, 
            {
                "Progress": 51, 
                "Time": 1566778796000
            }, 
            {
                "Progress": 54, 
                "Time": 1566778803000
            }, 
            {
                "Progress": 57, 
                "Time": 1566778809000
            }, 
            {
                "Progress": 61, 
                "Time": 1566778816000
            }, 
            {
                "Progress": 65, 
                "Time": 1566778823000
            }, 
            {
                "Progress": 68, 
                "Time": 1566778829000
            }, 
            {
                "Progress": 72, 
                "Time": 1566778836000
            }, 
            {
                "Progress": 75, 
                "Time": 1566778842000
            }, 
            {
                "Progress": 79, 
                "Time": 1566778849000
            }, 
            {
                "Progress": 82, 
                "Time": 1566778855000
            }, 
            {
                "Progress": 86, 
                "Time": 1566778862000
            }, 
            {
                "Progress": 89, 
                "Time": 1566778868000
            }, 
            {
                "Progress": 100, 
                "Time": 1566778873000
            }
        ], 
        "Test-VM-07": [
            {
                "Progress": 0, 
                "Time": 1566778754000
            }, 
            {
                "Progress": 34, 
                "Time": 1566778754000
            }, 
            {
                "Progress": 34, 
                "Time": 1566778757000
            }, 
            {
                "Progress": 35, 
                "Time": 1566778763000
            }, 
            {
                "Progress": 39, 
                "Time": 1566778770000
            }, 
            {
                "Progress": 42, 
                "Time": 1566778777000
            }, 
            {
                "Progress": 45, 
                "Time": 1566778783000
            }, 
            {
                "Progress": 48, 
                "Time": 1566778790000
            }, 
            {
                "Progress": 52, 
                "Time": 1566778797000
            }, 
            {
                "Progress": 55, 
                "Time": 1566778803000
            }, 
            {
                "Progress": 58, 
                "Time": 1566778810000
            }, 
            {
                "Progress": 62, 
                "Time": 1566778817000
            }, 
            {
                "Progress": 65, 
                "Time": 1566778823000
            }, 
            {
                "Progress": 68, 
                "Time": 1566778830000
            }, 
            {
                "Progress": 72, 
                "Time": 1566778836000
            }, 
            {
                "Progress": 75, 
                "Time": 1566778843000
            }, 
            {
                "Progress": 78, 
                "Time": 1566778849000
            }, 
            {
                "Progress": 81, 
                "Time": 1566778856000
            }, 
            {
                "Progress": 85, 
                "Time": 1566778862000
            }, 
            {
                "Progress": 88, 
                "Time": 1566778868000
            }, 
            {
                "Progress": null, 
                "Time": 1566778875000
            }, 
            {
                "Progress": 100, 
                "Time": 1566778876000
            }
        ], 
        "Test-VM-06": [
            {
                "Progress": 0, 
                "Time": 1566778754000
            }, 
            {
                "Progress": 34, 
                "Time": 1566778754000
            }, 
            {
                "Progress": 34, 
                "Time": 1566778757000
            }, 
            {
                "Progress": 35, 
                "Time": 1566778763000
            }, 
            {
                "Progress": 39, 
                "Time": 1566778770000
            }, 
            {
                "Progress": 41, 
                "Time": 1566778777000
            }, 
            {
                "Progress": 45, 
                "Time": 1566778783000
            }, 
            {
                "Progress": 48, 
                "Time": 1566778790000
            }, 
            {
                "Progress": 52, 
                "Time": 1566778797000
            }, 
            {
                "Progress": 54, 
                "Time": 1566778803000
            }, 
            {
                "Progress": 58, 
                "Time": 1566778810000
            }, 
            {
                "Progress": 61, 
                "Time": 1566778817000
            }, 
            {
                "Progress": 64, 
                "Time": 1566778823000
            }, 
            {
                "Progress": 68, 
                "Time": 1566778830000
            }, 
            {
                "Progress": 71, 
                "Time": 1566778836000
            }, 
            {
                "Progress": 75, 
                "Time": 1566778843000
            }, 
            {
                "Progress": 78, 
                "Time": 1566778849000
            }, 
            {
                "Progress": 81, 
                "Time": 1566778856000
            }, 
            {
                "Progress": 85, 
                "Time": 1566778862000
            }, 
            {
                "Progress": 89, 
                "Time": 1566778868000
            }, 
            {
                "Progress": 100, 
                "Time": 1566778875000
            }
        ]
    }
}