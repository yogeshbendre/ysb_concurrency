var testdata = {
    "nic": {
        "w1-hs4-n2204.eng.vmware.com": [
            {
                "vnic": "vmnic0", 
                "Bandwidth": 12, 
                "Time": 1566781109000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 28290, 
                "Time": 1566781120000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 28290, 
                "Time": 1566781131000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 18603, 
                "Time": 1566781142000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 18603, 
                "Time": 1566781152000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 2612, 
                "Time": 1566781163000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 2612, 
                "Time": 1566781174000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4858, 
                "Time": 1566781185000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4858, 
                "Time": 1566781195000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 367, 
                "Time": 1566781206000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 367, 
                "Time": 1566781217000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 342, 
                "Time": 1566781228000
            }
        ], 
        "w1-hs4-n2212.eng.vmware.com": [
            {
                "vnic": "vmnic0", 
                "Bandwidth": 17, 
                "Time": 1566781108000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 17, 
                "Time": 1566781119000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 55359, 
                "Time": 1566781130000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 32504, 
                "Time": 1566781141000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 32504, 
                "Time": 1566781151000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 8988, 
                "Time": 1566781162000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 8988, 
                "Time": 1566781173000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 9504, 
                "Time": 1566781183000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 9504, 
                "Time": 1566781194000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 718, 
                "Time": 1566781205000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 718, 
                "Time": 1566781216000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 648, 
                "Time": 1566781226000
            }
        ], 
        "w1-hs4-n2206.eng.vmware.com": [
            {
                "vnic": "vmnic0", 
                "Bandwidth": 17, 
                "Time": 1566781108000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 17, 
                "Time": 1566781119000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 55372, 
                "Time": 1566781130000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 34689, 
                "Time": 1566781141000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 34689, 
                "Time": 1566781151000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 6787, 
                "Time": 1566781162000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 6787, 
                "Time": 1566781173000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 9505, 
                "Time": 1566781184000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 9505, 
                "Time": 1566781194000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 706, 
                "Time": 1566781205000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 706, 
                "Time": 1566781216000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 642, 
                "Time": 1566781227000
            }
        ], 
        "w1-hs4-n2215.eng.vmware.com": [
            {
                "vnic": "vmnic0", 
                "Bandwidth": 10, 
                "Time": 1566781108000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 10, 
                "Time": 1566781119000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 28286, 
                "Time": 1566781130000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 16382, 
                "Time": 1566781141000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 16382, 
                "Time": 1566781151000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4830, 
                "Time": 1566781162000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4830, 
                "Time": 1566781173000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4874, 
                "Time": 1566781183000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4874, 
                "Time": 1566781194000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 380, 
                "Time": 1566781205000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 380, 
                "Time": 1566781216000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 347, 
                "Time": 1566781226000
            }
        ]
    }, 
    "datastore": {
        "Local-2204-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781109000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781120000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781131000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781142000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781152000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781163000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781174000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781185000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781195000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781206000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781217000
            }, 
            {
                "Read": 1, 
                "Write": 1, 
                "Time": 1566781228000
            }
        ], 
        "Local-2215-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781108000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781119000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781130000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781141000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781151000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781162000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781173000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781183000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781194000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781205000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781216000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781226000
            }
        ], 
        "Local-2212-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781108000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781119000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781130000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781141000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781151000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781162000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781173000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781183000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781194000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781205000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781216000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781226000
            }
        ], 
        "Local-2206-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781108000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781119000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781130000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781141000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781151000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781162000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781173000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781184000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781194000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781205000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781216000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566781227000
            }
        ]
    }, 
    "vm": {
        "Test-VM-13": [
            {
                "Progress": 0, 
                "Time": 1566781098000
            }, 
            {
                "Progress": 34, 
                "Time": 1566781098000
            }, 
            {
                "Progress": 34, 
                "Time": 1566781101000
            }, 
            {
                "Progress": 35, 
                "Time": 1566781108000
            }, 
            {
                "Progress": 39, 
                "Time": 1566781114000
            }, 
            {
                "Progress": 41, 
                "Time": 1566781121000
            }, 
            {
                "Progress": 44, 
                "Time": 1566781127000
            }, 
            {
                "Progress": 47, 
                "Time": 1566781133000
            }, 
            {
                "Progress": 50, 
                "Time": 1566781140000
            }, 
            {
                "Progress": 53, 
                "Time": 1566781146000
            }, 
            {
                "Progress": 57, 
                "Time": 1566781152000
            }, 
            {
                "Progress": 60, 
                "Time": 1566781159000
            }, 
            {
                "Progress": 63, 
                "Time": 1566781165000
            }, 
            {
                "Progress": 66, 
                "Time": 1566781171000
            }, 
            {
                "Progress": 69, 
                "Time": 1566781178000
            }, 
            {
                "Progress": 73, 
                "Time": 1566781184000
            }, 
            {
                "Progress": 76, 
                "Time": 1566781191000
            }, 
            {
                "Progress": 80, 
                "Time": 1566781197000
            }, 
            {
                "Progress": 83, 
                "Time": 1566781204000
            }, 
            {
                "Progress": 86, 
                "Time": 1566781210000
            }, 
            {
                "Progress": 89, 
                "Time": 1566781216000
            }, 
            {
                "Progress": 100, 
                "Time": 1566781221000
            }
        ], 
        "Test-VM-16": [
            {
                "Progress": 0, 
                "Time": 1566781098000
            }, 
            {
                "Progress": 34, 
                "Time": 1566781098000
            }, 
            {
                "Progress": 34, 
                "Time": 1566781102000
            }, 
            {
                "Progress": 35, 
                "Time": 1566781108000
            }, 
            {
                "Progress": 39, 
                "Time": 1566781115000
            }, 
            {
                "Progress": 42, 
                "Time": 1566781121000
            }, 
            {
                "Progress": 45, 
                "Time": 1566781127000
            }, 
            {
                "Progress": 47, 
                "Time": 1566781134000
            }, 
            {
                "Progress": 51, 
                "Time": 1566781140000
            }, 
            {
                "Progress": 53, 
                "Time": 1566781146000
            }, 
            {
                "Progress": 57, 
                "Time": 1566781153000
            }, 
            {
                "Progress": 60, 
                "Time": 1566781159000
            }, 
            {
                "Progress": 63, 
                "Time": 1566781166000
            }, 
            {
                "Progress": 66, 
                "Time": 1566781172000
            }, 
            {
                "Progress": 69, 
                "Time": 1566781178000
            }, 
            {
                "Progress": 73, 
                "Time": 1566781185000
            }, 
            {
                "Progress": 76, 
                "Time": 1566781191000
            }, 
            {
                "Progress": 80, 
                "Time": 1566781197000
            }, 
            {
                "Progress": 83, 
                "Time": 1566781204000
            }, 
            {
                "Progress": 87, 
                "Time": 1566781210000
            }, 
            {
                "Progress": 90, 
                "Time": 1566781217000
            }, 
            {
                "Progress": 100, 
                "Time": 1566781221000
            }
        ], 
        "Test-VM-14": [
            {
                "Progress": 0, 
                "Time": 1566781098000
            }, 
            {
                "Progress": 34, 
                "Time": 1566781098000
            }, 
            {
                "Progress": 34, 
                "Time": 1566781102000
            }, 
            {
                "Progress": 35, 
                "Time": 1566781108000
            }, 
            {
                "Progress": 39, 
                "Time": 1566781115000
            }, 
            {
                "Progress": 41, 
                "Time": 1566781121000
            }, 
            {
                "Progress": 44, 
                "Time": 1566781127000
            }, 
            {
                "Progress": 46, 
                "Time": 1566781134000
            }, 
            {
                "Progress": 50, 
                "Time": 1566781140000
            }, 
            {
                "Progress": 53, 
                "Time": 1566781146000
            }, 
            {
                "Progress": 57, 
                "Time": 1566781153000
            }, 
            {
                "Progress": 60, 
                "Time": 1566781159000
            }, 
            {
                "Progress": 63, 
                "Time": 1566781166000
            }, 
            {
                "Progress": 66, 
                "Time": 1566781172000
            }, 
            {
                "Progress": 69, 
                "Time": 1566781178000
            }, 
            {
                "Progress": 73, 
                "Time": 1566781185000
            }, 
            {
                "Progress": 76, 
                "Time": 1566781191000
            }, 
            {
                "Progress": 80, 
                "Time": 1566781197000
            }, 
            {
                "Progress": 83, 
                "Time": 1566781204000
            }, 
            {
                "Progress": 87, 
                "Time": 1566781210000
            }, 
            {
                "Progress": 90, 
                "Time": 1566781217000
            }, 
            {
                "Progress": 100, 
                "Time": 1566781221000
            }
        ], 
        "Test-VM-15": [
            {
                "Progress": 0, 
                "Time": 1566781098000
            }, 
            {
                "Progress": 34, 
                "Time": 1566781098000
            }, 
            {
                "Progress": 34, 
                "Time": 1566781102000
            }, 
            {
                "Progress": 35, 
                "Time": 1566781109000
            }, 
            {
                "Progress": 38, 
                "Time": 1566781115000
            }, 
            {
                "Progress": 41, 
                "Time": 1566781121000
            }, 
            {
                "Progress": 44, 
                "Time": 1566781128000
            }, 
            {
                "Progress": 46, 
                "Time": 1566781134000
            }, 
            {
                "Progress": 50, 
                "Time": 1566781140000
            }, 
            {
                "Progress": 53, 
                "Time": 1566781147000
            }, 
            {
                "Progress": 57, 
                "Time": 1566781153000
            }, 
            {
                "Progress": 60, 
                "Time": 1566781160000
            }, 
            {
                "Progress": 63, 
                "Time": 1566781166000
            }, 
            {
                "Progress": 66, 
                "Time": 1566781172000
            }, 
            {
                "Progress": 69, 
                "Time": 1566781179000
            }, 
            {
                "Progress": 73, 
                "Time": 1566781185000
            }, 
            {
                "Progress": 76, 
                "Time": 1566781191000
            }, 
            {
                "Progress": 80, 
                "Time": 1566781198000
            }, 
            {
                "Progress": 83, 
                "Time": 1566781204000
            }, 
            {
                "Progress": 87, 
                "Time": 1566781210000
            }, 
            {
                "Progress": 90, 
                "Time": 1566781217000
            }, 
            {
                "Progress": 100, 
                "Time": 1566781221000
            }
        ]
    }
}