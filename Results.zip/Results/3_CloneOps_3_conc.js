var testdata = {
    "nic": {
        "w1-hs4-n2202.eng.vmware.com": [
            {
                "vnic": "vmnic0", 
                "Bandwidth": 8, 
                "Time": 1566735451000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 28218, 
                "Time": 1566735461000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 28218, 
                "Time": 1566735472000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 16096, 
                "Time": 1566735483000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 16096, 
                "Time": 1566735494000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 5090, 
                "Time": 1566735504000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 5090, 
                "Time": 1566735515000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4858, 
                "Time": 1566735526000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4858, 
                "Time": 1566735537000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 341, 
                "Time": 1566735547000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 341, 
                "Time": 1566735558000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 362, 
                "Time": 1566735569000
            }
        ], 
        "w1-hs4-n2206.eng.vmware.com": [
            {
                "vnic": "vmnic0", 
                "Bandwidth": 8, 
                "Time": 1566735451000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 28226, 
                "Time": 1566735461000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 28226, 
                "Time": 1566735472000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 16273, 
                "Time": 1566735483000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 16273, 
                "Time": 1566735494000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4928, 
                "Time": 1566735504000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4928, 
                "Time": 1566735515000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4857, 
                "Time": 1566735526000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4857, 
                "Time": 1566735537000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 370, 
                "Time": 1566735548000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 370, 
                "Time": 1566735558000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 336, 
                "Time": 1566735569000
            }
        ], 
        "w1-hs4-n2214.eng.vmware.com": [
            {
                "vnic": "vmnic0", 
                "Bandwidth": 10, 
                "Time": 1566735451000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 28204, 
                "Time": 1566735462000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 28204, 
                "Time": 1566735473000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 16266, 
                "Time": 1566735484000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 16266, 
                "Time": 1566735495000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4926, 
                "Time": 1566735505000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4926, 
                "Time": 1566735516000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4858, 
                "Time": 1566735527000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4858, 
                "Time": 1566735538000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 355, 
                "Time": 1566735548000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 355, 
                "Time": 1566735559000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 349, 
                "Time": 1566735570000
            }
        ], 
        "w1-hs4-n2211.eng.vmware.com": [
            {
                "vnic": "vmnic0", 
                "Bandwidth": 8, 
                "Time": 1566735451000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 21, 
                "Time": 1566735461000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 21, 
                "Time": 1566735472000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 25, 
                "Time": 1566735483000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 25, 
                "Time": 1566735494000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 30, 
                "Time": 1566735504000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 30, 
                "Time": 1566735515000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 25, 
                "Time": 1566735526000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 25, 
                "Time": 1566735537000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 30, 
                "Time": 1566735547000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 30, 
                "Time": 1566735558000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 23, 
                "Time": 1566735569000
            }
        ]
    }, 
    "datastore": {
        "Local-2202-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735451000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735461000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735472000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735483000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735494000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735504000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735515000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735526000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735537000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735547000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735558000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735569000
            }
        ], 
        "Local-2206-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735451000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735461000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735472000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735483000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735494000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735504000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735515000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735526000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735537000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735548000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735558000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735569000
            }
        ], 
        "Local-2214-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735451000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735462000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735473000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735484000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735495000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735505000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735516000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735527000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735538000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735548000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735559000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566735570000
            }
        ]
    }, 
    "vm": {

        "Test-VM-05": [
            {
                "Progress": 0, 
                "Time": 1566735441000
            }, 
            {
                "Progress": 34, 
                "Time": 1566735441000
            }, 
            {
                "Progress": 34, 
                "Time": 1566735444000
            }, 
            {
                "Progress": 35, 
                "Time": 1566735451000
            }, 
            {
                "Progress": 39, 
                "Time": 1566735457000
            }, 
            {
                "Progress": 41, 
                "Time": 1566735463000
            }, 
            {
                "Progress": 44, 
                "Time": 1566735470000
            }, 
            {
                "Progress": 47, 
                "Time": 1566735476000
            }, 
            {
                "Progress": 50, 
                "Time": 1566735483000
            }, 
            {
                "Progress": 54, 
                "Time": 1566735489000
            }, 
            {
                "Progress": 57, 
                "Time": 1566735495000
            }, 
            {
                "Progress": 60, 
                "Time": 1566735502000
            }, 
            {
                "Progress": 63, 
                "Time": 1566735508000
            }, 
            {
                "Progress": 67, 
                "Time": 1566735515000
            }, 
            {
                "Progress": 69, 
                "Time": 1566735521000
            }, 
            {
                "Progress": 73, 
                "Time": 1566735527000
            }, 
            {
                "Progress": 76, 
                "Time": 1566735534000
            }, 
            {
                "Progress": 80, 
                "Time": 1566735540000
            }, 
            {
                "Progress": 83, 
                "Time": 1566735547000
            }, 
            {
                "Progress": 87, 
                "Time": 1566735553000
            }, 
            {
                "Progress": 89, 
                "Time": 1566735560000
            }, 
            {
                "Progress": 100, 
                "Time": 1566735564000
            }
        ], 
        "Test-VM-07": [
            {
                "Progress": 0, 
                "Time": 1566735442000
            }, 
            {
                "Progress": 34, 
                "Time": 1566735442000
            }, 
            {
                "Progress": 34, 
                "Time": 1566735445000
            }, 
            {
                "Progress": 35, 
                "Time": 1566735451000
            }, 
            {
                "Progress": 39, 
                "Time": 1566735458000
            }, 
            {
                "Progress": 41, 
                "Time": 1566735464000
            }, 
            {
                "Progress": 44, 
                "Time": 1566735471000
            }, 
            {
                "Progress": 46, 
                "Time": 1566735477000
            }, 
            {
                "Progress": 50, 
                "Time": 1566735483000
            }, 
            {
                "Progress": 53, 
                "Time": 1566735490000
            }, 
            {
                "Progress": 57, 
                "Time": 1566735496000
            }, 
            {
                "Progress": 59, 
                "Time": 1566735502000
            }, 
            {
                "Progress": 63, 
                "Time": 1566735509000
            }, 
            {
                "Progress": 66, 
                "Time": 1566735515000
            }, 
            {
                "Progress": 69, 
                "Time": 1566735522000
            }, 
            {
                "Progress": 72, 
                "Time": 1566735528000
            }, 
            {
                "Progress": 76, 
                "Time": 1566735534000
            }, 
            {
                "Progress": 79, 
                "Time": 1566735541000
            }, 
            {
                "Progress": 82, 
                "Time": 1566735547000
            }, 
            {
                "Progress": 86, 
                "Time": 1566735554000
            }, 
            {
                "Progress": 89, 
                "Time": 1566735560000
            }, 
            {
                "Progress": 100, 
                "Time": 1566735566000
            }
        ], 
        "Test-VM-06": [
            {
                "Progress": 0, 
                "Time": 1566735442000
            }, 
            {
                "Progress": 34, 
                "Time": 1566735442000
            }, 
            {
                "Progress": 34, 
                "Time": 1566735445000
            }, 
            {
                "Progress": 35, 
                "Time": 1566735451000
            }, 
            {
                "Progress": 39, 
                "Time": 1566735458000
            }, 
            {
                "Progress": 42, 
                "Time": 1566735464000
            }, 
            {
                "Progress": 44, 
                "Time": 1566735471000
            }, 
            {
                "Progress": 47, 
                "Time": 1566735477000
            }, 
            {
                "Progress": 50, 
                "Time": 1566735483000
            }, 
            {
                "Progress": 54, 
                "Time": 1566735490000
            }, 
            {
                "Progress": 57, 
                "Time": 1566735496000
            }, 
            {
                "Progress": 60, 
                "Time": 1566735502000
            }, 
            {
                "Progress": 63, 
                "Time": 1566735509000
            }, 
            {
                "Progress": 66, 
                "Time": 1566735515000
            }, 
            {
                "Progress": 69, 
                "Time": 1566735522000
            }, 
            {
                "Progress": 72, 
                "Time": 1566735528000
            }, 
            {
                "Progress": 76, 
                "Time": 1566735534000
            }, 
            {
                "Progress": 80, 
                "Time": 1566735541000
            }, 
            {
                "Progress": 83, 
                "Time": 1566735547000
            }, 
            {
                "Progress": 87, 
                "Time": 1566735554000
            }, 
            {
                "Progress": 89, 
                "Time": 1566735560000
            }, 
            {
                "Progress": 100, 
                "Time": 1566735565000
            }
        ]
    }
}