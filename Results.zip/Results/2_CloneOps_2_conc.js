var testdata = {
    "nic": {
        "w1-hs4-n2205.eng.vmware.com": [
            {
                "vnic": "vmnic0", 
                "Bandwidth": 10, 
                "Time": 1566734530000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 28225, 
                "Time": 1566734541000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 28225, 
                "Time": 1566734552000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 16278, 
                "Time": 1566734563000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 16278, 
                "Time": 1566734573000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4923, 
                "Time": 1566734584000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4923, 
                "Time": 1566734595000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4864, 
                "Time": 1566734606000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4864, 
                "Time": 1566734616000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 363, 
                "Time": 1566734627000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 363, 
                "Time": 1566734638000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 342, 
                "Time": 1566734649000
            }
        ], 
        "w1-hs4-n2213.eng.vmware.com": [
            {
                "vnic": "vmnic0", 
                "Bandwidth": 9, 
                "Time": 1566734530000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 28206, 
                "Time": 1566734541000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 28206, 
                "Time": 1566734552000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 16276, 
                "Time": 1566734563000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 16276, 
                "Time": 1566734574000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4920, 
                "Time": 1566734584000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4920, 
                "Time": 1566734595000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4876, 
                "Time": 1566734606000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 4876, 
                "Time": 1566734617000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 364, 
                "Time": 1566734627000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 364, 
                "Time": 1566734638000
            }, 
            {
                "vnic": "vmnic0", 
                "Bandwidth": 342, 
                "Time": 1566734649000
            }
        ]
    }, 
    "datastore": {
        "Local-2213-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734530000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734541000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734552000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734563000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734574000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734584000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734595000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734606000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734617000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734627000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734638000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734649000
            }
        ], 
        "Local-2205-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734530000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734541000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734552000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734563000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734573000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734584000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734595000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734606000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734616000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734627000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734638000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566734649000
            }
        ]
    }, 
    "vm": {
        "Test-VM-03": [
            {
                "Progress": 0, 
                "Time": 1566734522000
            }, 
            {
                "Progress": 34, 
                "Time": 1566734522000
            }, 
            {
                "Progress": 34, 
                "Time": 1566734525000
            }, 
            {
                "Progress": 35, 
                "Time": 1566734531000
            }, 
            {
                "Progress": 39, 
                "Time": 1566734537000
            }, 
            {
                "Progress": 42, 
                "Time": 1566734544000
            }, 
            {
                "Progress": 45, 
                "Time": 1566734550000
            }, 
            {
                "Progress": 47, 
                "Time": 1566734556000
            }, 
            {
                "Progress": 50, 
                "Time": 1566734563000
            }, 
            {
                "Progress": 54, 
                "Time": 1566734569000
            }, 
            {
                "Progress": 57, 
                "Time": 1566734575000
            }, 
            {
                "Progress": 60, 
                "Time": 1566734582000
            }, 
            {
                "Progress": 63, 
                "Time": 1566734588000
            }, 
            {
                "Progress": 67, 
                "Time": 1566734595000
            }, 
            {
                "Progress": 69, 
                "Time": 1566734601000
            }, 
            {
                "Progress": 73, 
                "Time": 1566734607000
            }, 
            {
                "Progress": 76, 
                "Time": 1566734614000
            }, 
            {
                "Progress": 80, 
                "Time": 1566734620000
            }, 
            {
                "Progress": 83, 
                "Time": 1566734626000
            }, 
            {
                "Progress": 87, 
                "Time": 1566734633000
            }, 
            {
                "Progress": 89, 
                "Time": 1566734639000
            }, 
            {
                "Progress": 100, 
                "Time": 1566734643000
            }
        ], 
        "Test-VM-04": [
            {
                "Progress": 0, 
                "Time": 1566734522000
            }, 
            {
                "Progress": 34, 
                "Time": 1566734522000
            }, 
            {
                "Progress": 34, 
                "Time": 1566734525000
            }, 
            {
                "Progress": 35, 
                "Time": 1566734532000
            }, 
            {
                "Progress": 39, 
                "Time": 1566734538000
            }, 
            {
                "Progress": 42, 
                "Time": 1566734544000
            }, 
            {
                "Progress": 45, 
                "Time": 1566734551000
            }, 
            {
                "Progress": 47, 
                "Time": 1566734557000
            }, 
            {
                "Progress": 51, 
                "Time": 1566734563000
            }, 
            {
                "Progress": 54, 
                "Time": 1566734570000
            }, 
            {
                "Progress": 57, 
                "Time": 1566734576000
            }, 
            {
                "Progress": 60, 
                "Time": 1566734582000
            }, 
            {
                "Progress": 63, 
                "Time": 1566734589000
            }, 
            {
                "Progress": 67, 
                "Time": 1566734595000
            }, 
            {
                "Progress": 69, 
                "Time": 1566734601000
            }, 
            {
                "Progress": 73, 
                "Time": 1566734608000
            }, 
            {
                "Progress": 76, 
                "Time": 1566734614000
            }, 
            {
                "Progress": 80, 
                "Time": 1566734621000
            }, 
            {
                "Progress": 83, 
                "Time": 1566734627000
            }, 
            {
                "Progress": 87, 
                "Time": 1566734633000
            }, 
            {
                "Progress": 90, 
                "Time": 1566734640000
            }, 
            {
                "Progress": 100, 
                "Time": 1566734643000
            }
        ]
    }
}