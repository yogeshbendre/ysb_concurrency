var testdata = {
    "nic": {
        "w1-hs4-n2205.eng.vmware.com": [
            {
                "vnic": "vmnic1", 
                "Bandwidth": 10, 
                "Time": 1566777397000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 32277, 
                "Time": 1566777408000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 32277, 
                "Time": 1566777419000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 35077, 
                "Time": 1566777430000
            }
        ], 
        "w1-hs4-n2211.eng.vmware.com": [
            {
                "vnic": "vmnic1", 
                "Bandwidth": 10, 
                "Time": 1566777397000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 32164, 
                "Time": 1566777407000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 32164, 
                "Time": 1566777418000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 35130, 
                "Time": 1566777429000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 43965, 
                "Time": 1566777440000
            }
        ], 
        "w1-hs4-n2209.eng.vmware.com": [
            {
                "vnic": "vmnic1", 
                "Bandwidth": 10, 
                "Time": 1566777396000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 31501, 
                "Time": 1566777407000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 31501, 
                "Time": 1566777417000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 35580, 
                "Time": 1566777428000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 35580, 
                "Time": 1566777439000
            }
        ], 
        "w1-hs4-n2214.eng.vmware.com": [
            {
                "vnic": "vmnic1", 
                "Bandwidth": 10, 
                "Time": 1566777397000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 31661, 
                "Time": 1566777408000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 31661, 
                "Time": 1566777419000
            }, 
            {
                "vnic": "vmnic1", 
                "Bandwidth": 35517, 
                "Time": 1566777429000
            }
        ]
    }, 
    "datastore": {
        "Local-2209-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566777396000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566777407000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566777417000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566777428000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566777439000
            }
        ], 
        "Local-2205-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566777397000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566777408000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566777419000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566777430000
            }
        ], 
        "Local-2211-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566777397000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566777407000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566777418000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566777429000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566777440000
            }
        ], 
        "Local-2214-1": [
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566777397000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566777408000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566777419000
            }, 
            {
                "Read": 0, 
                "Write": 0, 
                "Time": 1566777429000
            }
        ]
    }, 
    "vm": {
        "Test-VM-03": [
            {
                "Progress": 0, 
                "Time": 1566777388000
            }, 
            {
                "Progress": 22, 
                "Time": 1566777388000
            }, 
            {
                "Progress": 22, 
                "Time": 1566777391000
            }, 
            {
                "Progress": 29, 
                "Time": 1566777397000
            }, 
            {
                "Progress": 29, 
                "Time": 1566777404000
            }, 
            {
                "Progress": 38, 
                "Time": 1566777410000
            }, 
            {
                "Progress": 47, 
                "Time": 1566777416000
            }, 
            {
                "Progress": 47, 
                "Time": 1566777423000
            }, 
            {
                "Progress": null, 
                "Time": 1566777429000
            }, 
            {
                "Progress": 100, 
                "Time": 1566777429000
            }
        ], 
        "Test-VM-05": [
            {
                "Progress": 0, 
                "Time": 1566777388000
            }, 
            {
                "Progress": 22, 
                "Time": 1566777388000
            }, 
            {
                "Progress": 22, 
                "Time": 1566777391000
            }, 
            {
                "Progress": 32, 
                "Time": 1566777397000
            }, 
            {
                "Progress": 32, 
                "Time": 1566777404000
            }, 
            {
                "Progress": 38, 
                "Time": 1566777410000
            }, 
            {
                "Progress": 45, 
                "Time": 1566777416000
            }, 
            {
                "Progress": 45, 
                "Time": 1566777423000
            }, 
            {
                "Progress": 55, 
                "Time": 1566777429000
            }, 
            {
                "Progress": 100, 
                "Time": 1566777433000
            }
        ], 
        "Test-VM-07": [
            {
                "Progress": 0, 
                "Time": 1566777387000
            }, 
            {
                "Progress": 22, 
                "Time": 1566777387000
            }, 
            {
                "Progress": 22, 
                "Time": 1566777390000
            }, 
            {
                "Progress": 29, 
                "Time": 1566777396000
            }, 
            {
                "Progress": 29, 
                "Time": 1566777403000
            }, 
            {
                "Progress": 38, 
                "Time": 1566777409000
            }, 
            {
                "Progress": 46, 
                "Time": 1566777416000
            }, 
            {
                "Progress": 46, 
                "Time": 1566777422000
            }, 
            {
                "Progress": 72, 
                "Time": 1566777428000
            }, 
            {
                "Progress": 100, 
                "Time": 1566777431000
            }
        ], 
        "Test-VM-06": [
            {
                "Progress": 0, 
                "Time": 1566777388000
            }, 
            {
                "Progress": 22, 
                "Time": 1566777388000
            }, 
            {
                "Progress": 22, 
                "Time": 1566777391000
            }, 
            {
                "Progress": 29, 
                "Time": 1566777397000
            }, 
            {
                "Progress": 29, 
                "Time": 1566777404000
            }, 
            {
                "Progress": 38, 
                "Time": 1566777410000
            }, 
            {
                "Progress": 47, 
                "Time": 1566777416000
            }, 
            {
                "Progress": 47, 
                "Time": 1566777423000
            }, 
            {
                "Progress": 100, 
                "Time": 1566777429000
            }, 
            {
                "Progress": 100, 
                "Time": 1566777430000
            }
        ]
    }
}